# -*- coding: utf-8 -*-
"""
Created on Thu Apr 24 23:14:00 2025

@author: apurvabaru
"""

import ollama
import json
import streamlit as st
from azure.storage.blob import BlobServiceClient
from streamlit.components.v1 import html
import pandas as pd
import io
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Azure config from environment variables
container_name = os.getenv("AZURE_CONTAINER_NAME")
connect_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")

# ------------------------
# LOAD BLOB STORAGE
# ------------------------
@st.cache_data
def list_pd_files():
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_client = blob_service_client.get_container_client(container_name)
    return [blob.name for blob in container_client.list_blobs() if blob.name.endswith(".txt")]

def read_pd_file(filename):
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob=filename)
    stream = blob_client.download_blob()
    text = stream.readall().decode("utf-8")
    return text

# Read your CSV containing project_id and project_name
project_mapping = pd.read_csv("verra_detailed_projects.csv")

# Create a lookup dictionary
id_to_name = dict(zip(project_mapping['Project ID'].astype(str), project_mapping['Proponent']))
name_to_filename = {v: f"PD_{k}.txt" for k, v in id_to_name.items()}

available_files = list_pd_files()
filtered_name_to_filename = {
    name: filename
    for name, filename in name_to_filename.items()
    if filename in available_files
}

# ------------------------
# LLaMA RISK SCORING
# ------------------------
def analyze_veracity_risk(text, model_name="llama3.2"):
    prompt = f"""
        You are a carbon credit auditor.
        Given the following Project Description (PD), assign a **risk score from 0 to 10** based on how vague, unverifiable, or incomplete the project’s claims are.
        0 = Very low risk (clear, specific, complete)
        10 = High risk (vague, promotional, unverifiable, missing key info)
        Also list 2–3 bullet points explaining your reasoning. Be specific, actionable, and professional.
        Return your answer in this JSON format:
        {{
          "risk_score": <int>,
          "reasons": [
            "short explanation 1",
            "short explanation 2",
            "short explanation 3"
          ]
        }}
        PD:
        """
        {text[:3000]}
        """
    """

    response = ollama.chat(
        model=model_name,
        messages=[{"role": "user", "content": prompt}]
    )
    try:
        return json.loads(response['message']['content'])
    except Exception as e:
        return {"risk_score": -1, "reasons": ["Could not parse response"]}


# ------------------------
# STREAMLIT INTERFACE
# ------------------------
st.markdown("""
<style>
/* Style the download button the same as analyze */
div.stDownloadButton > button:first-child {
    background-color: white;
    color: #4CAF50;
    border: 2px solid #4CAF50;
    border-radius: 8px;
    padding: 0.6em 1.5em;
    font-weight: 600;
    transition: 0.2s ease;
}
div.stDownloadButton > button:first-child:active {
    background-color: #4CAF50 !important;
    color: white !important;
    border: 2px solid #4CAF50;
}
div.stDownloadButton > button:first-child:hover {
    background-color: #f1f1f1;
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>
/* Default button style */
div.stButton > button:first-child {
    background-color: white;
    color: #4CAF50;
    border: 2px solid #4CAF50;
    border-radius: 8px;
    padding: 0.6em 1.5em;
    font-weight: 600;
    transition: 0.2s ease;
}

/* On click (active) */
div.stButton > button:first-child:active {
    background-color: #4CAF50 !important;
    color: white !important;
    border: 2px solid #4CAF50;
}

/* On hover (optional for better UX) */
div.stButton > button:first-child:hover {
    background-color: #f1f1f1;
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>
/* Style the selectbox (dropdown) wrapper */
[data-baseweb="select"] > div {
    border: 2px solid #4CAF50 !important;
    border-radius: 8px !important;
}

/* On focus (when clicked/selected) */
[data-baseweb="select"]:focus-within > div {
    border: 2px solid #4CAF50 !important;
    box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3) !important;
}
</style>
""", unsafe_allow_html=True)

#st.title("Carbon Project Veracity Analyzer")
st.markdown("""
<h1 style='text-align: center; font-size: 42px; color: #333;'>🌿 Carbon Veracity Analyzer</h1>
<h6 style='text-align: center; color: #666;'>Your Intelligent Auditor for Carbon Credit Transparency</h4>
""", unsafe_allow_html=True)

project_names = sorted(filtered_name_to_filename.keys())

selected_project_name = st.selectbox(
    "Select a project to analyze:",
    options=project_names
)
selected_file = filtered_name_to_filename[selected_project_name]

# ------------------------
# ANALYZE BUTTON
# ------------------------
if st.button("Analyze Veracity"):
    with st.spinner("Analyzing with LLaMA 3.2..."):
        text = read_pd_file(selected_file)
        result = analyze_veracity_risk(text)

        st.session_state["veracity_result"] = result
        st.session_state["selected_file"] = selected_file
        st.session_state["selected_project_name"] = selected_project_name
        st.session_state["pd_text"] = text

# ------------------------
# RESULT DISPLAY
# ------------------------
if "veracity_result" in st.session_state:
    result = st.session_state["veracity_result"]
    selected_file = st.session_state["selected_file"]
    selected_project_name = st.session_state["selected_project_name"]
    text = st.session_state["pd_text"]

    st.subheader("🧭 Risk Score")

    risk_score = result["risk_score"]
    bar_html = f"""
    <div style="position: relative; width: 100%; height: 70px; margin-bottom: 20px;">
      <div style="position: absolute; top: 0px; width: 100%; display: flex; justify-content: space-between; font-size: 12px; color: #666;">
        <span>Low</span>
        <span>Medium</span>
        <span>High</span>
      </div>
      <div style="position: absolute; top: 20px; width: 100%; height: 30px; background: linear-gradient(90deg, #4CAF50, #FFEB3B, #F44336); border-radius: 15px; box-shadow: inset 0 0 5px rgba(0,0,0,0.1);"></div>
      <div style="position: absolute; top: 16px; left: {risk_score * 10}%; transform: translateX(-50%); text-align: center;">
        <div style="font-size: 12px; font-weight: bold; color: #111;">▲<br>{risk_score}/10</div>
      </div>
    </div>
    """
    st.markdown(bar_html, unsafe_allow_html=True)

    st.subheader("🔍 Reasoning:")
    for reason in result["reasons"]:
        st.write("-", reason)

    if result["risk_score"] >= 0:
        export_data = {
            "project": selected_project_name,
            "filename": selected_file,
            "risk_score": result["risk_score"],
            "reasons": result["reasons"]
        }
        json_bytes = io.BytesIO(json.dumps(export_data, indent=2).encode("utf-8"))
        st.download_button(
            "📥 Download Risk Report",
            data=json_bytes,
            file_name=f"{selected_file.replace('.txt', '')}_risk_report.json",
            mime="application/json"
        )

    with st.expander("📂 View Full Project Description"):
        st.text_area("Raw PD Text", text[:10000], height=300)

# ✅ Project count display
st.success(f"Showing {len(project_names)} available projects.")


